const accountRequest=/^(?:открой|покажи)\s+(?:мой\s+)?(?:аккаунт(?:ы)?\s+(?:гугл|google)|гугл аккаунт(?:ы)?|google аккаунт(?:ы)?|аккаунты google)$/.test(norm);
const youtubeNumberWords={первое:1,первый:1,один:1,одно:1,второе:2,второй:2,два:2,две:2,третье:3,третий:3,три:3,четвертое:4,четвёртое:4,четвертый:4,четвёртый:4,четыре:4,пятое:5,пятый:5,пять:5,шестое:6,шестой:6,шесть:6,седьмое:7,седьмой:7,семь:7,восьмое:8,восьмой:8,восемь:8,девятое:9,девятый:9,девять:9,десятое:10,десятый:10,десять:10};
const youtubeOrdinal=norm.match(/^(?:(?:открой|включи|запусти|покажи)\s+)?(?:(?:видео)\s+(?:номер\s+)?)?(первое|первый|одно|один|второе|второй|два|две|третье|третий|три|четвертое|четвёртое|четвертый|четвёртый|четыре|пятое|пятый|пять|шестое|шестой|шесть|седьмое|седьмой|семь|восьмое|восьмой|восемь|девятое|девятый|девять|десятое|десятый|десять|\d{1,2})(?:\s+видео)?(?:\s+пожалуйста)?$/);
const youtubeSearchMatch=norm.match(/(?:найди|поищи|ищи)\s+(?:мне\s+)?(?:видео\s*|видеообзор\s+|ролик\s+|клип\s+)(.+?)(?:\s+(?:на\s+)?(?:ютубе|youtube))?$/)||norm.match(/(?:найди|поищи|ищи)\s+(?:мне\s+)?(.+?)\s+(?:на\s+)?(?:ютубе|youtube)$/)||norm.match(/(?:на\s+)?(?:ютубе|youtube)\s+(?:найди|поищи|ищи)\s+(.+)/);
let searchMatch=norm.match(/(?:в гугле|в гугл|в google|в браузере google)\s*(?:найди|поищи|введи|напиши в поиске|ищи)\s+(.+)/)||norm.match(/(?:найди|поищи)\s+(.+?)\s+(?:в гугле|в google)$/);
if(!searchMatch){const intro=norm.match(/^(?:я\s+)?(?:заш[её]л|открыл|переш[её]л)\s+в\s+(?:гугл|google|браузер)\s+(.+)$/);if(intro)searchMatch=intro[1].match(/^(?:найди|поищи|введи|напиши в поиске)\s+(.+)$/)}
const telegramChatMatch=norm.match(/(?:в тг|в телеграме|в телеграм|телеграм|telegram)\s+(?:открой|найди|зайди(?: в)?|перейди(?: в)?)\s+(?:чат\s+)?(.+)/)||norm.match(/(?:открой|найди|зайди в)\s+чат\s+(?:по (?:нику|имени|названию)\s+)?(.+)/);
const telegramScrollRequest=/(?:пролистай|прокрути|листани|пролистать|прокрутить).*(?:чаты|чат|список).*(?:вниз|ниже)|(?:пролистай|прокрути|листани|пролистать|прокрутить)\s+(?:вниз|ниже).*(?:чаты|чат|список)/.test(norm);
const telegramScrollUpRequest=/(?:пролистай|прокрути|листани|пролистать|прокрутить).*(?:чаты|чат|список).*(?:вверх|выше|наверх)|(?:пролистай|прокрути|листани|пролистать|прокрутить)\s+(?:вверх|выше|наверх).*(?:чаты|чат|список)|^(?:вверх|выше|наверх)$/.test(norm);
const telegramBackRequest=/^(?:закрой|закрыть|назад|выйди из)\s+(?:текущий\s+)?(?:чат|переписку)/.test(norm);
const telegramDraft=String(t).trim().match(/^(?:напиши|надиктуй|набери)(?:\s+сообщение)?\s+(.+)$/i);
const telegramSendRequest=/^(?:отправь|отправить|пошли)(?:\s+сообщение)?$/.test(norm);
const desktopStartRequest=/^(?:пуск|создай второй рабочий стол|открой второй рабочий стол|перейди на второй рабочий стол)$/.test(norm);
const desktopCloseRequest=/^(?:импульс|удали второй рабочий стол|закрой второй рабочий стол|вернись на обычный рабочий стол)$/.test(norm);
if(youtubeOrdinal||youtubeSearchMatch||searchMatch||accountRequest||telegramChatMatch||telegramScrollRequest||telegramScrollUpRequest||telegramBackRequest||telegramDraft||telegramSendRequest||desktopStartRequest||desktopCloseRequest){
  let command,reply;
  if(youtubeOrdinal){const key=youtubeOrdinal[1];const n=/^\d+$/.test(key)?Number(key):youtubeNumberWords[key];command='youtube-open:'+n;reply='Открываю видео номер '+n+' на весь экран.'}
  else if(youtubeSearchMatch){const query=youtubeSearchMatch[1].trim();command='youtube-search:'+query;reply='Ищу на YouTube: '+query}
  else if(searchMatch){const query=searchMatch[1].trim();if(!query||query.length>300){const err='Поисковый запрос слишком длинный.';$('msg').textContent=err;speak(err);return}command='google-search:'+query;reply='Ищу в Google: '+query}
  else if(accountRequest){command='google-accounts';reply='Открываю страницу аккаунтов Google.'}
  else if(telegramScrollUpRequest){command='telegram-scroll-up';reply='Прокручиваю список чатов Telegram вверх.'}
  else if(telegramScrollRequest){command='telegram-scroll-down';reply='Прокручиваю список чатов Telegram вниз.'}
  else if(telegramBackRequest){command='telegram-back';reply='Возвращаюсь к списку чатов.'}
  else if(telegramDraft){command='telegram-type:'+telegramDraft[1].trim();reply='Ввожу сообщение. Скажи «отправь», чтобы отправить.'}
  else if(telegramSendRequest){command='telegram-send';reply='Отправляю сообщение.'}
  else if(desktopStartRequest){command='desktop-start';reply='Создаю второй рабочий стол.'}
  else if(desktopCloseRequest){command='desktop-close';reply='Закрываю второй рабочий стол и возвращаюсь.'}
  else{const chatName=telegramChatMatch[1].replace(/^(?:по нику|по имени|по названию)\s+/,'').replace(/^с\s+/,'').trim();command='telegram-chat:'+chatName;reply='Ищу чат Telegram «'+chatName+'»'}
  $('msg').textContent=reply;speak(reply);
  try{const r=await fetch('/launch?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command})});const d=await r.json();if(!r.ok||!d.ok)throw Error()}catch{const err='Не удалось выполнить команду. Проверь, что нужное приложение запущено.';$('msg').textContent=err;speak(err)}return
}
if(!searchMatch){const quickSearch=norm.match(/^найди\s+(.+)$/);if(quickSearch){const query=quickSearch[1].trim();const command='smart-search:'+query;$('msg').textContent='Ищу: '+query;speak('Ищу: '+query);try{const r=await fetch('/launch?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command})});const d=await r.json();if(!r.ok||!d.ok)throw Error()}catch{}return}}
